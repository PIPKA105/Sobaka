# Keep JS bridge
-keepclassmembers class com.youyube.anonim.MainActivity$ModBridge { *; }
