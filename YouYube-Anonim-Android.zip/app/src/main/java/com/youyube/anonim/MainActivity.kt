package com.youyube.anonim

import android.annotation.SuppressLint
import android.content.Context
import android.content.pm.ActivityInfo
import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.os.Build
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.view.WindowManager
import android.webkit.CookieManager
import android.webkit.JavascriptInterface
import android.webkit.WebChromeClient
import android.webkit.WebResourceRequest
import android.webkit.WebResourceResponse
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.ArrayAdapter
import android.widget.Button
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.SeekBar
import android.widget.Spinner
import android.widget.Switch
import android.widget.TextView
import androidx.activity.OnBackPressedCallback
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.WindowInsetsControllerCompat
import org.json.JSONObject

class MainActivity : AppCompatActivity() {

    private lateinit var webView: WebView
    private lateinit var rootLayout: FrameLayout
    private lateinit var topModButton: TextView
    private var customView: View? = null
    private var customViewCallback: WebChromeClient.CustomViewCallback? = null

    private val prefs by lazy {
        getSharedPreferences("youyube_anonim_prefs", Context.MODE_PRIVATE)
    }

    private val modScript: String by lazy {
        assets.open("youyube_mod.js").bufferedReader().use { it.readText() }
    }

    private fun dp(value: Int): Int {
        return (value * resources.displayMetrics.density).toInt()
    }

    @SuppressLint("SetJavaScriptEnabled")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        rootLayout = FrameLayout(this).apply {
            setBackgroundColor(Color.parseColor("#0F0F14"))
            fitsSystemWindows = true
        }
        webView = WebView(this).apply {
            layoutParams = FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.MATCH_PARENT
            )
            setBackgroundColor(Color.parseColor("#0F0F14"))
        }
        rootLayout.addView(webView)

        // Native top-bar button placed right next to the YouTube Search icon
        topModButton = TextView(this).apply {
            text = "⚙ Мод"
            setTextColor(Color.WHITE)
            textSize = 13f
            gravity = Gravity.CENTER
            setPadding(dp(12), dp(6), dp(12), dp(6))
            background = GradientDrawable().apply {
                cornerRadius = dp(18).toFloat()
                setColor(Color.parseColor("#CC1C1C28"))
                setStroke(dp(1), Color.parseColor("#FF2442"))
            }
            layoutParams = FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.WRAP_CONTENT,
                dp(32),
                Gravity.TOP or Gravity.END
            ).apply {
                topMargin = dp(8)
                marginEnd = dp(52)
            }
            setOnClickListener { showNativeModSettingsDialog() }
        }
        rootLayout.addView(topModButton)

        setContentView(rootLayout)

        setupWebView()
        setupBackNavigation()

        val targetUrl = intent?.data?.toString()?.takeIf { it.startsWith("http") }
            ?: "https://m.youtube.com"
        webView.loadUrl(targetUrl)
    }

    private fun showNativeModSettingsDialog() {
        val cfg = getSettingsJson()

        val scroll = ScrollView(this).apply {
            setBackgroundColor(Color.parseColor("#161622"))
            setPadding(dp(18), dp(12), dp(18), dp(12))
        }
        val container = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
        }
        scroll.addView(container)

        fun addHeader(title: String) {
            val tv = TextView(this).apply {
                text = title
                setTextColor(Color.parseColor("#FF2442"))
                textSize = 12f
                setPadding(0, dp(12), 0, dp(4))
            }
            container.addView(tv)
        }

        fun addSwitch(label: String, checked: Boolean): Switch {
            val sw = Switch(this).apply {
                text = label
                isChecked = checked
                setTextColor(Color.WHITE)
                textSize = 15f
                setPadding(0, dp(6), 0, dp(6))
            }
            container.addView(sw)
            return sw
        }

        addHeader("РЕКЛАМА И РЕКОМЕНДАЦИИ")
        val swAdBlock = addSwitch("Авто-скрытие рекламы", cfg.optBoolean("adBlock", true))
        val swShorts = addSwitch("Скрыть Shorts", cfg.optBoolean("hideShorts", false))
        val swHomeFeed = addSwitch("Скрыть ленту главной", cfg.optBoolean("hideHomeFeed", false))
        val swRelated = addSwitch("Скрыть похожие видео", cfg.optBoolean("hideRelated", false))
        val swComments = addSwitch("Скрыть комментарии", cfg.optBoolean("hideComments", false))

        val kwLabel = TextView(this).apply {
            text = "Фильтр рекомендаций (слова через запятую):"
            setTextColor(Color.LTGRAY)
            textSize = 13f
            setPadding(0, dp(8), 0, dp(4))
        }
        container.addView(kwLabel)
        val etKeywords = EditText(this).apply {
            setText(cfg.optString("keywordFilter", ""))
            hint = "реклама, обзор, кликбейт"
            setTextColor(Color.WHITE)
            setHintTextColor(Color.GRAY)
            setBackgroundColor(Color.parseColor("#0F0F18"))
            setPadding(dp(10), dp(8), dp(10), dp(8))
        }
        container.addView(etKeywords)

        addHeader("АВАТАРКА")
        val shapeLabels = listOf("Круг", "Скругленный квадрат", "Квадрат", "Шестиугольник", "Ромб")
        val shapeValues = listOf("circle", "squircle", "square", "hexagon", "diamond")
        val spShape = Spinner(this).apply {
            adapter = ArrayAdapter(this@MainActivity, android.R.layout.simple_spinner_dropdown_item, shapeLabels)
            setSelection(shapeValues.indexOf(cfg.optString("avatarShape", "circle")).coerceAtLeast(0))
        }
        container.addView(TextView(this).apply {
            text = "Форма аватарки:"
            setTextColor(Color.LTGRAY)
            textSize = 13f
            setPadding(0, dp(6), 0, dp(2))
        })
        container.addView(spShape)

        val borderLabels = listOf("Неоновое свечение", "Сплошная", "Пунктир", "Двойная", "Градиент", "Без рамки")
        val borderValues = listOf("neon", "solid", "dashed", "double", "rainbow", "none")
        val spBorder = Spinner(this).apply {
            adapter = ArrayAdapter(this@MainActivity, android.R.layout.simple_spinner_dropdown_item, borderLabels)
            setSelection(borderValues.indexOf(cfg.optString("avatarBorderStyle", "neon")).coerceAtLeast(0))
        }
        container.addView(TextView(this).apply {
            text = "Стиль рамки:"
            setTextColor(Color.LTGRAY)
            textSize = 13f
            setPadding(0, dp(8), 0, dp(2))
        })
        container.addView(spBorder)

        val etBorderColor = EditText(this).apply {
            setText(cfg.optString("avatarBorderColor", "#FF2442"))
            setTextColor(Color.WHITE)
            setBackgroundColor(Color.parseColor("#0F0F18"))
            setPadding(dp(10), dp(6), dp(10), dp(6))
        }
        container.addView(TextView(this).apply {
            text = "Цвет рамки (HEX):"
            setTextColor(Color.LTGRAY)
            textSize = 13f
            setPadding(0, dp(8), 0, dp(2))
        })
        container.addView(etBorderColor)

        val swatches = listOf("#FF2442", "#00E5FF", "#00E676", "#FFB800", "#A855F7", "#FFFFFF")
        fun makeSwatchBar(target: EditText): LinearLayout {
            return LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL
                setPadding(0, dp(6), 0, dp(4))
                swatches.forEach { hex ->
                    val b = Button(this@MainActivity).apply {
                        layoutParams = LinearLayout.LayoutParams(dp(32), dp(32)).apply { marginEnd = dp(8) }
                        background = GradientDrawable().apply {
                            shape = GradientDrawable.OVAL
                            setColor(Color.parseColor(hex))
                            setStroke(dp(1), Color.GRAY)
                        }
                        setOnClickListener { target.setText(hex) }
                    }
                    addView(b)
                }
            }
        }
        container.addView(makeSwatchBar(etBorderColor))

        val curW = cfg.optInt("avatarBorderWidth", 3).coerceIn(1, 6)
        val widthLabel = TextView(this).apply {
            text = "Толщина рамки: ${curW}px"
            setTextColor(Color.LTGRAY)
            textSize = 13f
            setPadding(0, dp(6), 0, dp(2))
        }
        container.addView(widthLabel)
        val sbWidth = SeekBar(this).apply {
            max = 5
            progress = curW - 1
            setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(s: SeekBar?, p: Int, fromUser: Boolean) {
                    widthLabel.text = "Толщина рамки: ${p + 1}px"
                }
                override fun onStartTrackingTouch(s: SeekBar?) {}
                override fun onStopTrackingTouch(s: SeekBar?) {}
            })
        }
        container.addView(sbWidth)

        addHeader("ЦВЕТ ЗНАЧКОВ")
        val swIconColor = addSwitch("Свой цвет значков", cfg.optBoolean("customIconEnabled", true))
        val etIconColor = EditText(this).apply {
            setText(cfg.optString("iconColor", "#FF2442"))
            setTextColor(Color.WHITE)
            setBackgroundColor(Color.parseColor("#0F0F18"))
            setPadding(dp(10), dp(6), dp(10), dp(6))
        }
        container.addView(etIconColor)
        container.addView(makeSwatchBar(etIconColor))

        AlertDialog.Builder(this)
            .setTitle("YouYube Anonim Mod")
            .setView(scroll)
            .setPositiveButton("Применить") { _, _ ->
                val updated = JSONObject().apply {
                    put("adBlock", swAdBlock.isChecked)
                    put("hideShorts", swShorts.isChecked)
                    put("hideHomeFeed", swHomeFeed.isChecked)
                    put("hideRelated", swRelated.isChecked)
                    put("hideComments", swComments.isChecked)
                    put("keywordFilter", etKeywords.text.toString())
                    put("avatarShape", shapeValues[spShape.selectedItemPosition])
                    put("avatarBorderStyle", borderValues[spBorder.selectedItemPosition])
                    put("avatarBorderColor", etBorderColor.text.toString().ifBlank { "#FF2442" })
                    put("avatarBorderWidth", sbWidth.progress + 1)
                    put("customIconEnabled", swIconColor.isChecked)
                    put("iconColor", etIconColor.text.toString().ifBlank { "#FF2442" })
                }
                prefs.edit().putString("config_json", updated.toString()).apply()
                webView.evaluateJavascript("window.__youyubeAnonimRefresh && window.__youyubeAnonimRefresh();", null)
            }
            .setNegativeButton("Отмена", null)
            .show()
    }

    private fun setFullscreenMode(enabled: Boolean) {
        val controller = WindowInsetsControllerCompat(window, rootLayout)
        if (enabled) {
            WindowCompat.setDecorFitsSystemWindows(window, false)
            rootLayout.fitsSystemWindows = false
            controller.hide(WindowInsetsCompat.Type.systemBars())
            controller.systemBarsBehavior =
                WindowInsetsControllerCompat.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) {
                window.attributes.layoutInDisplayCutoutMode =
                    WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES
            }
        } else {
            WindowCompat.setDecorFitsSystemWindows(window, true)
            rootLayout.fitsSystemWindows = true
            controller.show(WindowInsetsCompat.Type.systemBars())
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) {
                window.attributes.layoutInDisplayCutoutMode =
                    WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_DEFAULT
            }
        }
        rootLayout.requestLayout()
    }

    @SuppressLint("SetJavaScriptEnabled")
    private fun setupWebView() {
        val cookieManager = CookieManager.getInstance()
        cookieManager.setAcceptCookie(true)
        cookieManager.setAcceptThirdPartyCookies(webView, true)

        webView.settings.apply {
            javaScriptEnabled = true
            domStorageEnabled = true
            databaseEnabled = true
            mediaPlaybackRequiresUserGesture = false
            loadsImagesAutomatically = true
            useWideViewPort = true
            loadWithOverviewMode = true
            mixedContentMode = WebSettings.MIXED_CONTENT_COMPATIBILITY_MODE
            userAgentString = userAgentString.replace("; wv", "")
        }

        webView.addJavascriptInterface(ModBridge(), "YouYubeAnonimNative")

        webView.webViewClient = object : WebViewClient() {
            override fun shouldOverrideUrlLoading(
                view: WebView?,
                request: WebResourceRequest?
            ): Boolean {
                val url = request?.url?.toString() ?: return false
                if (url.startsWith("intent://") ||
                    url.startsWith("vnd.youtube://") ||
                    url.startsWith("market://") ||
                    url.contains("play.google.com/store/apps")
                ) {
                    return true
                }
                return false
            }

            override fun shouldInterceptRequest(
                view: WebView?,
                request: WebResourceRequest?
            ): WebResourceResponse? {
                val url = request?.url?.toString()
                val adBlockEnabled = getSettingsJson().optBoolean("adBlock", true)
                if (adBlockEnabled && AdBlocker.isAdRequest(url)) {
                    return AdBlocker.emptyResponse()
                }
                return super.shouldInterceptRequest(view, request)
            }

            override fun onPageFinished(view: WebView?, url: String?) {
                super.onPageFinished(view, url)
                injectModScript()
            }
        }

        webView.webChromeClient = object : WebChromeClient() {
            override fun onShowCustomView(view: View?, callback: CustomViewCallback?) {
                if (customView != null) {
                    callback?.onCustomViewHidden()
                    return
                }
                customView = view
                customViewCallback = callback
                rootLayout.addView(
                    view,
                    FrameLayout.LayoutParams(
                        ViewGroup.LayoutParams.MATCH_PARENT,
                        ViewGroup.LayoutParams.MATCH_PARENT
                    )
                )
                webView.visibility = View.GONE
                topModButton.visibility = View.GONE
                setFullscreenMode(true)
                requestedOrientation = ActivityInfo.SCREEN_ORIENTATION_SENSOR_LANDSCAPE
            }

            override fun onHideCustomView() {
                customView?.let { rootLayout.removeView(it) }
                customView = null
                customViewCallback?.onCustomViewHidden()
                customViewCallback = null
                webView.visibility = View.VISIBLE
                topModButton.visibility = View.VISIBLE
                setFullscreenMode(false)
                requestedOrientation = ActivityInfo.SCREEN_ORIENTATION_UNSPECIFIED
            }
        }
    }

    private fun injectModScript() {
        webView.evaluateJavascript(modScript, null)
    }

    private fun getSettingsJson(): JSONObject {
        val raw = prefs.getString("config_json", null)
        return if (raw != null) {
            try { JSONObject(raw) } catch (_: Exception) { defaultSettings() }
        } else {
            defaultSettings()
        }
    }

    private fun defaultSettings(): JSONObject {
        return JSONObject().apply {
            put("adBlock", true)
            put("hideShorts", false)
            put("hideHomeFeed", false)
            put("hideRelated", false)
            put("hideComments", false)
            put("keywordFilter", "")
            put("avatarShape", "circle")
            put("avatarBorderStyle", "neon")
            put("avatarBorderColor", "#FF2442")
            put("avatarBorderWidth", 3)
            put("iconColor", "#FF2442")
            put("customIconEnabled", true)
        }
    }

    inner class ModBridge {
        @JavascriptInterface
        fun getConfig(): String {
            return getSettingsJson().toString()
        }

        @JavascriptInterface
        fun saveConfig(json: String) {
            prefs.edit().putString("config_json", json).apply()
        }
    }

    private fun setupBackNavigation() {
        onBackPressedDispatcher.addCallback(this, object : OnBackPressedCallback(true) {
            override fun handleOnBackPressed() {
                if (customView != null) {
                    webView.webChromeClient?.onHideCustomView()
                } else if (webView.canGoBack()) {
                    webView.goBack()
                } else {
                    finish()
                }
            }
        })
    }
}
