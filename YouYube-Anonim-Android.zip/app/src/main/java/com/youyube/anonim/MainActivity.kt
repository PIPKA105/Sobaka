package com.youyube.anonim

import android.annotation.SuppressLint
import android.content.Context
import android.content.pm.ActivityInfo
import android.graphics.Color
import android.graphics.drawable.ColorDrawable
import android.graphics.drawable.GradientDrawable
import android.media.AudioAttributes
import android.media.AudioFormat
import android.media.AudioTrack
import android.os.Build
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.view.WindowManager
import android.webkit.CookieManager
import android.webkit.JavascriptInterface
import android.webkit.WebChromeClient
import android.webkit.WebResourceRequest
import android.webkit.WebResourceResponse
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.ArrayAdapter
import android.widget.Button
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.SeekBar
import android.widget.Spinner
import android.widget.Switch
import android.widget.TextView
import androidx.activity.OnBackPressedCallback
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.WindowInsetsControllerCompat
import org.json.JSONObject
import kotlin.math.PI
import kotlin.math.exp
import kotlin.math.sin

class MainActivity : AppCompatActivity() {

    private lateinit var webView: WebView
    private lateinit var rootLayout: FrameLayout
    private lateinit var topModButton: TextView
    private var customView: View? = null
    private var customViewCallback: WebChromeClient.CustomViewCallback? = null
    private var inShortsMode: Boolean = false

    private val prefs by lazy {
        getSharedPreferences("youyube_anonim_prefs", Context.MODE_PRIVATE)
    }

    private val modScript: String by lazy {
        assets.open("youyube_mod.js").bufferedReader().use { it.readText() }
    }

    private fun dp(value: Int): Int {
        return (value * resources.displayMetrics.density).toInt()
    }

    private fun playToggleSound(high: Boolean = true) {
        Thread {
            try {
                val sampleRate = 22050
                val durationMs = 45
                val numSamples = sampleRate * durationMs / 1000
                val samples = ShortArray(numSamples)
                val baseFreq = if (high) 760.0 else 540.0
                for (i in 0 until numSamples) {
                    val t = i.toDouble() / sampleRate
                    val env = exp(-t * 65.0)
                    val tone = sin(2.0 * PI * baseFreq * t) * 0.65 + sin(2.0 * PI * baseFreq * 1.5 * t) * 0.35
                    samples[i] = (tone * env * 12000.0).toInt().toShort()
                }
                val track = AudioTrack.Builder()
                    .setAudioAttributes(
                        AudioAttributes.Builder()
                            .setUsage(AudioAttributes.USAGE_ASSISTANCE_SONIFICATION)
                            .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
                            .build()
                    )
                    .setAudioFormat(
                        AudioFormat.Builder()
                            .setEncoding(AudioFormat.ENCODING_PCM_16BIT)
                            .setSampleRate(sampleRate)
                            .setChannelMask(AudioFormat.CHANNEL_OUT_MONO)
                            .build()
                    )
                    .setBufferSizeInBytes(numSamples * 2)
                    .setTransferMode(AudioTrack.MODE_STATIC)
                    .build()
                track.write(samples, 0, numSamples)
                track.play()
                Thread.sleep(60)
                track.release()
            } catch (_: Exception) {
            }
        }.start()
    }

    private fun updateTopButtonVisibility() {
        topModButton.visibility = if (customView != null || inShortsMode) View.GONE else View.VISIBLE
    }

    @SuppressLint("SetJavaScriptEnabled")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        rootLayout = FrameLayout(this).apply {
            setBackgroundColor(Color.parseColor("#0F0F14"))
            fitsSystemWindows = true
        }
        webView = WebView(this).apply {
            layoutParams = FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.MATCH_PARENT
            )
            setBackgroundColor(Color.parseColor("#0F0F14"))
        }
        rootLayout.addView(webView)

        topModButton = TextView(this).apply {
            text = "⚙ Мод"
            setTextColor(Color.WHITE)
            textSize = 13f
            gravity = Gravity.CENTER
            setPadding(dp(12), dp(6), dp(12), dp(6))
            background = GradientDrawable().apply {
                cornerRadius = dp(12).toFloat()
                setColor(Color.parseColor("#DD181826"))
                setStroke(dp(1), Color.parseColor("#FF2442"))
            }
            layoutParams = FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.WRAP_CONTENT,
                dp(32),
                Gravity.TOP or Gravity.END
            ).apply {
                topMargin = dp(8)
                marginEnd = dp(52)
            }
            setOnClickListener {
                playToggleSound(true)
                showNativeModSettingsDialog()
            }
        }
        rootLayout.addView(topModButton)

        setContentView(rootLayout)

        setupWebView()
        setupBackNavigation()

        val targetUrl = intent?.data?.toString()?.takeIf { it.startsWith("http") }
            ?: "https://m.youtube.com"
        webView.loadUrl(targetUrl)
    }

    private fun roundedBox(bgHex: String, radiusDp: Int, strokeHex: String? = null): GradientDrawable {
        return GradientDrawable().apply {
            cornerRadius = dp(radiusDp).toFloat()
            setColor(Color.parseColor(bgHex))
            if (strokeHex != null) {
                setStroke(dp(1), Color.parseColor(strokeHex))
            }
        }
    }

    private fun showNativeModSettingsDialog() {
        val cfg = getSettingsJson()

        val rootCard = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            background = roundedBox("#151521", 24, "#2F2F45")
            setPadding(dp(18), dp(18), dp(18), dp(14))
        }

        val titleBar = TextView(this).apply {
            text = "YouYube Anonim Mod"
            setTextColor(Color.parseColor("#FF2442"))
            textSize = 19f
            setPadding(0, 0, 0, dp(10))
        }
        rootCard.addView(titleBar)

        val scroll = ScrollView(this).apply {
            layoutParams = LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                dp(430)
            )
        }
        val container = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
        }
        scroll.addView(container)
        rootCard.addView(scroll)

        fun addSectionCard(title: String): LinearLayout {
            val tv = TextView(this).apply {
                text = title
                setTextColor(Color.parseColor("#A5A5BE"))
                textSize = 11f
                setPadding(dp(4), dp(10), 0, dp(4))
            }
            container.addView(tv)

            val card = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL
                background = roundedBox("#1E1E2E", 16, "#2D2D42")
                setPadding(dp(12), dp(10), dp(12), dp(10))
            }
            container.addView(card)
            return card
        }

        fun addSwitch(parent: LinearLayout, label: String, checked: Boolean): Switch {
            val sw = Switch(this).apply {
                text = label
                isChecked = checked
                setTextColor(Color.WHITE)
                textSize = 14f
                setPadding(0, dp(6), 0, dp(6))
                setOnCheckedChangeListener { _, isChecked ->
                    playToggleSound(isChecked)
                }
            }
            parent.addView(sw)
            return sw
        }

        val secAds = addSectionCard("РЕКЛАМА И РЕКОМЕНДАЦИИ")
        val swAdBlock = addSwitch(secAds, "Авто-скрытие рекламы", cfg.optBoolean("adBlock", true))
        val swShorts = addSwitch(secAds, "Скрыть Shorts", cfg.optBoolean("hideShorts", false))
        val swHomeFeed = addSwitch(secAds, "Скрыть ленту главной", cfg.optBoolean("hideHomeFeed", false))
        val swRelated = addSwitch(secAds, "Скрыть похожие видео", cfg.optBoolean("hideRelated", false))
        val swComments = addSwitch(secAds, "Скрыть комментарии", cfg.optBoolean("hideComments", false))

        secAds.addView(TextView(this).apply {
            text = "Фильтр по словам (через запятую):"
            setTextColor(Color.LTGRAY)
            textSize = 12f
            setPadding(0, dp(8), 0, dp(4))
        })
        val etKeywords = EditText(this).apply {
            setText(cfg.optString("keywordFilter", ""))
            hint = "реклама, обзор, кликбейт"
            setTextColor(Color.WHITE)
            setHintTextColor(Color.GRAY)
            background = roundedBox("#12121C", 12, "#32324A")
            setPadding(dp(12), dp(8), dp(12), dp(8))
        }
        secAds.addView(etKeywords)

        val secAvatar = addSectionCard("АВАТАРКА")
        val shapeLabels = listOf("Круг", "Скругленный квадрат", "Квадрат", "Шестиугольник", "Ромб")
        val shapeValues = listOf("circle", "squircle", "square", "hexagon", "diamond")
        val spShape = Spinner(this).apply {
            adapter = ArrayAdapter(this@MainActivity, android.R.layout.simple_spinner_dropdown_item, shapeLabels)
            setSelection(shapeValues.indexOf(cfg.optString("avatarShape", "circle")).coerceAtLeast(0))
            background = roundedBox("#12121C", 12, "#32324A")
        }
        secAvatar.addView(TextView(this).apply {
            text = "Форма аватарки:"
            setTextColor(Color.LTGRAY)
            textSize = 12f
            setPadding(0, dp(4), 0, dp(4))
        })
        secAvatar.addView(spShape)

        val borderLabels = listOf("Неоновое свечение", "Сплошная", "Пунктир", "Двойная", "Градиент", "Без рамки")
        val borderValues = listOf("neon", "solid", "dashed", "double", "rainbow", "none")
        val spBorder = Spinner(this).apply {
            adapter = ArrayAdapter(this@MainActivity, android.R.layout.simple_spinner_dropdown_item, borderLabels)
            setSelection(borderValues.indexOf(cfg.optString("avatarBorderStyle", "neon")).coerceAtLeast(0))
            background = roundedBox("#12121C", 12, "#32324A")
        }
        secAvatar.addView(TextView(this).apply {
            text = "Стиль рамки:"
            setTextColor(Color.LTGRAY)
            textSize = 12f
            setPadding(0, dp(8), 0, dp(4))
        })
        secAvatar.addView(spBorder)

        val etBorderColor = EditText(this).apply {
            setText(cfg.optString("avatarBorderColor", "#FF2442"))
            setTextColor(Color.WHITE)
            background = roundedBox("#12121C", 12, "#32324A")
            setPadding(dp(12), dp(8), dp(12), dp(8))
        }
        secAvatar.addView(TextView(this).apply {
            text = "Цвет рамки:"
            setTextColor(Color.LTGRAY)
            textSize = 12f
            setPadding(0, dp(8), 0, dp(4))
        })
        secAvatar.addView(etBorderColor)

        val swatches = listOf("#FF2442", "#00E5FF", "#00E676", "#FFB800", "#A855F7", "#FFFFFF")
        fun makeSwatchBar(target: EditText): LinearLayout {
            return LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL
                setPadding(0, dp(8), 0, dp(4))
                swatches.forEach { hex ->
                    val b = Button(this@MainActivity).apply {
                        layoutParams = LinearLayout.LayoutParams(dp(32), dp(32)).apply { marginEnd = dp(8) }
                        background = GradientDrawable().apply {
                            cornerRadius = dp(10).toFloat()
                            setColor(Color.parseColor(hex))
                            setStroke(dp(1), Color.GRAY)
                        }
                        setOnClickListener {
                            playToggleSound(true)
                            target.setText(hex)
                        }
                    }
                    addView(b)
                }
            }
        }
        secAvatar.addView(makeSwatchBar(etBorderColor))

        val curW = cfg.optInt("avatarBorderWidth", 3).coerceIn(1, 6)
        val widthLabel = TextView(this).apply {
            text = "Толщина рамки: ${curW}px"
            setTextColor(Color.LTGRAY)
            textSize = 12f
            setPadding(0, dp(6), 0, dp(2))
        }
        secAvatar.addView(widthLabel)
        val sbWidth = SeekBar(this).apply {
            max = 5
            progress = curW - 1
            setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(s: SeekBar?, p: Int, fromUser: Boolean) {
                    widthLabel.text = "Толщина рамки: ${p + 1}px"
                }
                override fun onStartTrackingTouch(s: SeekBar?) {}
                override fun onStopTrackingTouch(s: SeekBar?) {}
            })
        }
        secAvatar.addView(sbWidth)

        val secIcons = addSectionCard("ЦВЕТ ЗНАЧКОВ")
        val swIconColor = addSwitch(secIcons, "Свой цвет значков", cfg.optBoolean("customIconEnabled", true))
        val etIconColor = EditText(this).apply {
            setText(cfg.optString("iconColor", "#FF2442"))
            setTextColor(Color.WHITE)
            background = roundedBox("#12121C", 12, "#32324A")
            setPadding(dp(12), dp(8), dp(12), dp(8))
        }
        secIcons.addView(etIconColor)
        secIcons.addView(makeSwatchBar(etIconColor))

        val btnRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            setPadding(0, dp(14), 0, 0)
        }
        val btnCancel = Button(this).apply {
            text = "Отмена"
            setTextColor(Color.LTGRAY)
            background = roundedBox("#242436", 14)
            layoutParams = LinearLayout.LayoutParams(0, dp(44), 1f).apply { marginEnd = dp(8) }
        }
        val btnSave = Button(this).apply {
            text = "Применить"
            setTextColor(Color.WHITE)
            background = roundedBox("#FF2442", 14)
            layoutParams = LinearLayout.LayoutParams(0, dp(44), 1.4f)
        }
        btnRow.addView(btnCancel)
        btnRow.addView(btnSave)
        rootCard.addView(btnRow)

        val dialog = AlertDialog.Builder(this)
            .setView(rootCard)
            .create()
        dialog.window?.setBackgroundDrawable(ColorDrawable(Color.TRANSPARENT))

        btnCancel.setOnClickListener {
            playToggleSound(false)
            dialog.dismiss()
        }
        btnSave.setOnClickListener {
            playToggleSound(true)
            val updated = JSONObject().apply {
                put("adBlock", swAdBlock.isChecked)
                put("hideShorts", swShorts.isChecked)
                put("hideHomeFeed", swHomeFeed.isChecked)
                put("hideRelated", swRelated.isChecked)
                put("hideComments", swComments.isChecked)
                put("keywordFilter", etKeywords.text.toString())
                put("avatarShape", shapeValues[spShape.selectedItemPosition])
                put("avatarBorderStyle", borderValues[spBorder.selectedItemPosition])
                put("avatarBorderColor", etBorderColor.text.toString().ifBlank { "#FF2442" })
                put("avatarBorderWidth", sbWidth.progress + 1)
                put("customIconEnabled", swIconColor.isChecked)
                put("iconColor", etIconColor.text.toString().ifBlank { "#FF2442" })
            }
            prefs.edit().putString("config_json", updated.toString()).apply()
            webView.evaluateJavascript("window.__youyubeAnonimRefresh && window.__youyubeAnonimRefresh();", null)
            dialog.dismiss()
        }

        dialog.show()
    }

    private fun setFullscreenMode(enabled: Boolean) {
        val controller = WindowInsetsControllerCompat(window, rootLayout)
        if (enabled) {
            WindowCompat.setDecorFitsSystemWindows(window, false)
            rootLayout.fitsSystemWindows = false
            controller.hide(WindowInsetsCompat.Type.systemBars())
            controller.systemBarsBehavior =
                WindowInsetsControllerCompat.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) {
                window.attributes.layoutInDisplayCutoutMode =
                    WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES
            }
        } else {
            WindowCompat.setDecorFitsSystemWindows(window, true)
            rootLayout.fitsSystemWindows = true
            controller.show(WindowInsetsCompat.Type.systemBars())
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) {
                window.attributes.layoutInDisplayCutoutMode =
                    WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_DEFAULT
            }
        }
        rootLayout.requestLayout()
    }

    @SuppressLint("SetJavaScriptEnabled")
    private fun setupWebView() {
        val cookieManager = CookieManager.getInstance()
        cookieManager.setAcceptCookie(true)
        cookieManager.setAcceptThirdPartyCookies(webView, true)

        webView.settings.apply {
            javaScriptEnabled = true
            domStorageEnabled = true
            databaseEnabled = true
            mediaPlaybackRequiresUserGesture = false
            loadsImagesAutomatically = true
            useWideViewPort = true
            loadWithOverviewMode = true
            mixedContentMode = WebSettings.MIXED_CONTENT_COMPATIBILITY_MODE
            userAgentString = userAgentString.replace("; wv", "")
        }

        webView.addJavascriptInterface(ModBridge(), "YouYubeAnonimNative")

        webView.webViewClient = object : WebViewClient() {
            override fun shouldOverrideUrlLoading(
                view: WebView?,
                request: WebResourceRequest?
            ): Boolean {
                val url = request?.url?.toString() ?: return false
                if (url.startsWith("intent://") ||
                    url.startsWith("vnd.youtube://") ||
                    url.startsWith("market://") ||
                    url.contains("play.google.com/store/apps")
                ) {
                    return true
                }
                return false
            }

            override fun shouldInterceptRequest(
                view: WebView?,
                request: WebResourceRequest?
            ): WebResourceResponse? {
                val url = request?.url?.toString()
                val adBlockEnabled = getSettingsJson().optBoolean("adBlock", true)
                if (adBlockEnabled && AdBlocker.isAdRequest(url)) {
                    return AdBlocker.emptyResponse()
                }
                return super.shouldInterceptRequest(view, request)
            }

            override fun onPageFinished(view: WebView?, url: String?) {
                super.onPageFinished(view, url)
                injectModScript()
            }
        }

        webView.webChromeClient = object : WebChromeClient() {
            override fun onShowCustomView(view: View?, callback: CustomViewCallback?) {
                if (customView != null) {
                    callback?.onCustomViewHidden()
                    return
                }
                customView = view
                customViewCallback = callback
                rootLayout.addView(
                    view,
                    FrameLayout.LayoutParams(
                        ViewGroup.LayoutParams.MATCH_PARENT,
                        ViewGroup.LayoutParams.MATCH_PARENT
                    )
                )
                webView.visibility = View.GONE
                updateTopButtonVisibility()
                setFullscreenMode(true)
                requestedOrientation = ActivityInfo.SCREEN_ORIENTATION_SENSOR_LANDSCAPE
            }

            override fun onHideCustomView() {
                customView?.let { rootLayout.removeView(it) }
                customView = null
                customViewCallback?.onCustomViewHidden()
                customViewCallback = null
                webView.visibility = View.VISIBLE
                updateTopButtonVisibility()
                setFullscreenMode(false)
                requestedOrientation = ActivityInfo.SCREEN_ORIENTATION_UNSPECIFIED
            }
        }
    }

    private fun injectModScript() {
        webView.evaluateJavascript(modScript, null)
    }

    private fun getSettingsJson(): JSONObject {
        val raw = prefs.getString("config_json", null)
        return if (raw != null) {
            try { JSONObject(raw) } catch (_: Exception) { defaultSettings() }
        } else {
            defaultSettings()
        }
    }

    private fun defaultSettings(): JSONObject {
        return JSONObject().apply {
            put("adBlock", true)
            put("hideShorts", false)
            put("hideHomeFeed", false)
            put("hideRelated", false)
            put("hideComments", false)
            put("keywordFilter", "")
            put("avatarShape", "circle")
            put("avatarBorderStyle", "neon")
            put("avatarBorderColor", "#FF2442")
            put("avatarBorderWidth", 3)
            put("iconColor", "#FF2442")
            put("customIconEnabled", true)
        }
    }

    inner class ModBridge {
        @JavascriptInterface
        fun getConfig(): String {
            return getSettingsJson().toString()
        }

        @JavascriptInterface
        fun saveConfig(json: String) {
            prefs.edit().putString("config_json", json).apply()
        }

        @JavascriptInterface
        fun setShortsMode(inShorts: Boolean) {
            runOnUiThread {
                inShortsMode = inShorts
                updateTopButtonVisibility()
            }
        }
    }

    private fun setupBackNavigation() {
        onBackPressedDispatcher.addCallback(this, object : OnBackPressedCallback(true) {
            override fun handleOnBackPressed() {
                if (customView != null) {
                    webView.webChromeClient?.onHideCustomView()
                } else if (webView.canGoBack()) {
                    webView.goBack()
                } else {
                    finish()
                }
            }
        })
    }
}
