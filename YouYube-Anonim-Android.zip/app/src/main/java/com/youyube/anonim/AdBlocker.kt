package com.youyube.anonim

import android.net.Uri
import android.webkit.WebResourceResponse
import java.io.ByteArrayInputStream

object AdBlocker {
    private val blockedHosts = setOf(
        "doubleclick.net",
        "googleadservices.com",
        "googlesyndication.com",
        "adservice.google.com",
        "pagead2.googlesyndication.com",
        "tpc.googlesyndication.com",
        "s0.2mdn.net",
        "ads.youtube.com"
    )

    private val blockedPaths = listOf(
        "/pagead/",
        "/api/stats/ads",
        "/ptracking",
        "/get_midroll_info",
        "/youtubei/v1/player/ad_break"
    )

    fun isAdRequest(url: String?): Boolean {
        if (url.isNullOrBlank()) return false
        val uri = try { Uri.parse(url) } catch (_: Exception) { return false }
        val host = uri.host?.lowercase() ?: ""
        if (blockedHosts.any { host == it || host.endsWith(".$it") }) {
            return true
        }
        val path = uri.path?.lowercase() ?: ""
        if (host.contains("youtube.com") && blockedPaths.any { path.contains(it) }) {
            return true
        }
        return false
    }

    fun emptyResponse(): WebResourceResponse {
        return WebResourceResponse("text/plain", "utf-8", ByteArrayInputStream(ByteArray(0)))
    }
}
