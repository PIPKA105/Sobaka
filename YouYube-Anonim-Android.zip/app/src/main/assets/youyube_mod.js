(function() {
    if (window.__youyubeAnonimLoaded) {
        if (window.__youyubeAnonimApply) window.__youyubeAnonimApply();
        return;
    }
    window.__youyubeAnonimLoaded = true;

    const DEFAULT_CFG = {
        adBlock: true,
        hideShorts: false,
        hideHomeFeed: false,
        hideRelated: false,
        hideComments: false,
        keywordFilter: "",
        avatarShape: "circle",
        avatarBorderStyle: "neon",
        avatarBorderColor: "#FF2442",
        avatarBorderWidth: 3,
        iconColor: "#FF2442",
        customIconEnabled: true
    };

    function loadConfig() {
        try {
            if (window.YouYubeAnonimNative) {
                return Object.assign({}, DEFAULT_CFG, JSON.parse(window.YouYubeAnonimNative.getConfig()));
            }
            const local = localStorage.getItem("youyube_anonim_cfg");
            return local ? Object.assign({}, DEFAULT_CFG, JSON.parse(local)) : Object.assign({}, DEFAULT_CFG);
        } catch (e) {
            return Object.assign({}, DEFAULT_CFG);
        }
    }

    function saveConfig(cfg) {
        try {
            const str = JSON.stringify(cfg);
            localStorage.setItem("youyube_anonim_cfg", str);
            if (window.YouYubeAnonimNative) {
                window.YouYubeAnonimNative.saveConfig(str);
            }
        } catch (e) {}
    }

    let cfg = loadConfig();

    function ensureStyleEl() {
        let el = document.getElementById("yy-anonim-style");
        if (!el) {
            el = document.createElement("style");
            el.id = "yy-anonim-style";
            document.head.appendChild(el);
        }
        return el;
    }

    function getAvatarShapeCSS(shape) {
        switch (shape) {
            case "squircle":
                return "border-radius: 26% !important; clip-path: none !important;";
            case "square":
                return "border-radius: 6px !important; clip-path: none !important;";
            case "hexagon":
                return "border-radius: 0 !important; clip-path: polygon(50% 0%, 95% 25%, 95% 75%, 50% 100%, 5% 75%, 5% 25%) !important;";
            case "diamond":
                return "border-radius: 0 !important; clip-path: polygon(50% 0%, 100% 50%, 50% 100%, 0% 50%) !important;";
            case "circle":
            default:
                return "border-radius: 50% !important; clip-path: none !important;";
        }
    }

    function getAvatarBorderCSS(style, color, width) {
        if (style === "none") return "border: none !important; box-shadow: none !important;";
        if (style === "dashed") return `border: ${width}px dashed ${color} !important; box-shadow: none !important;`;
        if (style === "double") return `border: ${width}px double ${color} !important; box-shadow: none !important;`;
        if (style === "neon") return `border: ${width}px solid ${color} !important; box-shadow: 0 0 10px ${color}, 0 0 4px ${color} !important;`;
        if (style === "rainbow") return `border: ${width}px solid transparent !important; background: linear-gradient(135deg, #ff2442, #ffb800, #00e5ff, #9b51e0) border-box !important; box-shadow: 0 0 8px rgba(255,36,66,0.5) !important;`;
        return `border: ${width}px solid ${color} !important; box-shadow: none !important;`;
    }

    function applyStyles() {
        const el = ensureStyleEl();
        const avatarSel = [
            "ytm-profile-icon img",
            "yt-img-shadow img",
            ".yt-spec-avatar-shape__image",
            "ytm-channel-thumbnail-with-link-renderer img",
            "#avatar img",
            ".channel-thumbnail img"
        ].join(", ");

        const iconSel = [
            "ytm-pivot-bar-item-renderer svg",
            "ytm-mobile-topbar-renderer svg",
            "ytm-slim-video-action-bar-renderer svg",
            "button.icon-button svg",
            ".yt-spec-button-shape-next__icon svg",
            "yt-icon svg"
        ].join(", ");

        let css = `
            /* Avatar Shape & Border */
            ${avatarSel} {
                ${getAvatarShapeCSS(cfg.avatarShape)}
                ${getAvatarBorderCSS(cfg.avatarBorderStyle, cfg.avatarBorderColor, cfg.avatarBorderWidth)}
                box-sizing: border-box !important;
                transition: all 0.2s ease !important;
            }
            .yt-spec-avatar-shape__avatar-image-container,
            yt-avatar-shape,
            .yt-spec-avatar-shape {
                ${getAvatarShapeCSS(cfg.avatarShape)}
                overflow: visible !important;
            }
        `;

        if (cfg.customIconEnabled) {
            css += `
                ${iconSel} {
                    color: ${cfg.iconColor} !important;
                    fill: ${cfg.iconColor} !important;
                }
                ${iconSel} path {
                    fill: currentColor !important;
                }
            `;
        }

        if (cfg.adBlock) {
            css += `
                ytm-promoted-sparkles-web-renderer,
                ytm-promoted-sparkles-text-search-renderer,
                ytm-ad-slot-renderer,
                ytd-ad-slot-renderer,
                ytm-companion-slot-renderer,
                .ytp-ad-module,
                .ytp-ad-overlay-container,
                .ad-created-by-yt,
                [data-ad-slot-id] {
                    display: none !important;
                }
            `;
        }

        if (cfg.hideShorts) {
            css += `
                ytm-reel-shelf-renderer,
                ytm-shorts-lockup-view-model,
                ytm-pivot-bar-item-renderer[tab-identifier="FEshorts"],
                a[href^="/shorts"] {
                    display: none !important;
                }
            `;
        }

        if (cfg.hideHomeFeed) {
            css += `
                ytm-browse[data-browse-id="FEwhat_to_watch"] ytm-rich-grid-renderer,
                ytm-browse[data-browse-id="FEwhat_to_watch"] ytm-section-list-renderer {
                    display: none !important;
                }
            `;
        }

        if (cfg.hideRelated) {
            css += `
                ytm-item-section-renderer[section-identifier="related-items"],
                ytm-single-column-watch-next-results-renderer ytm-section-list-renderer > lazy-list > ytm-item-section-renderer:nth-child(n+2) {
                    display: none !important;
                }
            `;
        }

        if (cfg.hideComments) {
            css += `
                ytm-comments-entry-point-header-renderer,
                ytm-comment-section-renderer {
                    display: none !important;
                }
            `;
        }

        el.textContent = css;
        applyKeywordFilter();
    }

    function applyKeywordFilter() {
        const raw = (cfg.keywordFilter || "").trim();
        const keywords = raw ? raw.split(",").map(s => s.trim().toLowerCase()).filter(Boolean) : [];
        const cards = document.querySelectorAll("ytm-video-with-context-renderer, ytm-rich-item-renderer, ytm-compact-video-renderer");
        cards.forEach(card => {
            if (!keywords.length) {
                card.style.removeProperty("display");
                return;
            }
            const text = (card.innerText || "").toLowerCase();
            const matched = keywords.some(kw => text.includes(kw));
            if (matched) {
                card.style.display = "none";
            } else {
                card.style.removeProperty("display");
            }
        });
    }

    function skipAdsTick() {
        if (!cfg.adBlock) return;
        const skipBtn = document.querySelector(".ytp-ad-skip-button, .ytp-ad-skip-button-modern, .ytp-skip-ad-button, button[class*='skip']");
        if (skipBtn) {
            skipBtn.click();
        }
        const player = document.querySelector(".html5-video-player");
        const video = document.querySelector("video");
        if (player && video && (player.classList.contains("ad-showing") || player.classList.contains("ad-interrupting"))) {
            video.muted = true;
            if (isFinite(video.duration) && video.duration > 0) {
                video.currentTime = video.duration;
            } else {
                video.playbackRate = 16.0;
            }
        }
    }

    function createModUI() {
        if (document.getElementById("yy-anonim-fab")) return;

        const fab = document.createElement("button");
        fab.id = "yy-anonim-fab";
        fab.textContent = "⚙ Anonim";
        Object.assign(fab.style, {
            position: "fixed",
            bottom: "72px",
            right: "14px",
            zIndex: "999999",
            background: "linear-gradient(135deg, #1a1a26, #2a1220)",
            color: "#ffffff",
            border: "1.5px solid #ff2442",
            borderRadius: "20px",
            padding: "8px 14px",
            fontSize: "12px",
            fontWeight: "700",
            boxShadow: "0 4px 14px rgba(255, 36, 66, 0.35)",
            cursor: "pointer"
        });

        const modal = document.createElement("div");
        modal.id = "yy-anonim-modal";
        Object.assign(modal.style, {
            display: "none",
            position: "fixed",
            inset: "0",
            zIndex: "1000000",
            background: "rgba(10, 10, 16, 0.82)",
            backdropFilter: "blur(6px)",
            alignItems: "center",
            justifyContent: "center",
            padding: "16px"
        });

        modal.innerHTML = `
            <div style="background:#161622;color:#f3f3f7;border:1px solid #2e2e42;border-radius:16px;width:100%;max-width:380px;max-height:85vh;overflow-y:auto;padding:18px;font-family:sans-serif;box-shadow:0 16px 40px rgba(0,0,0,0.6);">
                <div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:14px;">
                    <span style="font-size:17px;font-weight:700;color:#ff2442;">YouYube Anonim Mod</span>
                    <button id="yy-close" style="background:#262638;color:#fff;border:none;border-radius:8px;padding:6px 10px;font-size:13px;">✕</button>
                </div>

                <div style="font-size:12px;color:#9a9ab0;margin:10px 0 6px;font-weight:700;">РЕКЛАМА И РЕКОМЕНДАЦИИ</div>
                <label style="display:flex;justify-content:space-between;align-items:center;padding:6px 0;font-size:14px;">
                    <span>Авто-скрытие рекламы</span>
                    <input type="checkbox" id="yy-adBlock">
                </label>
                <label style="display:flex;justify-content:space-between;align-items:center;padding:6px 0;font-size:14px;">
                    <span>Скрыть Shorts</span>
                    <input type="checkbox" id="yy-hideShorts">
                </label>
                <label style="display:flex;justify-content:space-between;align-items:center;padding:6px 0;font-size:14px;">
                    <span>Скрыть ленту главной</span>
                    <input type="checkbox" id="yy-hideHomeFeed">
                </label>
                <label style="display:flex;justify-content:space-between;align-items:center;padding:6px 0;font-size:14px;">
                    <span>Скрыть похожие видео</span>
                    <input type="checkbox" id="yy-hideRelated">
                </label>
                <label style="display:flex;justify-content:space-between;align-items:center;padding:6px 0;font-size:14px;">
                    <span>Скрыть комментарии</span>
                    <input type="checkbox" id="yy-hideComments">
                </label>
                <div style="margin:6px 0 10px;">
                    <div style="font-size:13px;margin-bottom:4px;">Фильтр рекомендаций (слова через запятую):</div>
                    <input type="text" id="yy-keywordFilter" placeholder="реклама, обзор, кликбейт" style="width:100%;box-sizing:border-box;background:#0f0f18;color:#fff;border:1px solid #32324a;border-radius:8px;padding:8px;font-size:13px;">
                </div>

                <div style="font-size:12px;color:#9a9ab0;margin:12px 0 6px;font-weight:700;">АВАТАРКА</div>
                <div style="display:flex;justify-content:space-between;align-items:center;padding:6px 0;font-size:14px;">
                    <span>Форма аватарки</span>
                    <select id="yy-avatarShape" style="background:#0f0f18;color:#fff;border:1px solid #32324a;border-radius:8px;padding:5px 8px;">
                        <option value="circle">Круг</option>
                        <option value="squircle">Скругленный квадрат</option>
                        <option value="square">Квадрат</option>
                        <option value="hexagon">Шестиугольник</option>
                        <option value="diamond">Ромб</option>
                    </select>
                </div>
                <div style="display:flex;justify-content:space-between;align-items:center;padding:6px 0;font-size:14px;">
                    <span>Стиль рамки</span>
                    <select id="yy-avatarBorderStyle" style="background:#0f0f18;color:#fff;border:1px solid #32324a;border-radius:8px;padding:5px 8px;">
                        <option value="neon">Неоновое свечение</option>
                        <option value="solid">Сплошная</option>
                        <option value="dashed">Пунктир</option>
                        <option value="double">Двойная</option>
                        <option value="rainbow">Градиент</option>
                        <option value="none">Без рамки</option>
                    </select>
                </div>
                <div style="display:flex;justify-content:space-between;align-items:center;padding:6px 0;font-size:14px;">
                    <span>Цвет рамки</span>
                    <input type="color" id="yy-avatarBorderColor" style="width:44px;height:30px;border:none;background:none;">
                </div>
                <div style="display:flex;justify-content:space-between;align-items:center;padding:6px 0;font-size:14px;">
                    <span>Толщина рамки (<span id="yy-bwVal">3</span>px)</span>
                    <input type="range" id="yy-avatarBorderWidth" min="1" max="6" step="1">
                </div>

                <div style="font-size:12px;color:#9a9ab0;margin:12px 0 6px;font-weight:700;">ЗНАЧКИ ИКОНОК</div>
                <label style="display:flex;justify-content:space-between;align-items:center;padding:6px 0;font-size:14px;">
                    <span>Свой цвет значков</span>
                    <input type="checkbox" id="yy-customIconEnabled">
                </label>
                <div style="display:flex;justify-content:space-between;align-items:center;padding:6px 0;font-size:14px;">
                    <span>Цвет значков</span>
                    <input type="color" id="yy-iconColor" style="width:44px;height:30px;border:none;background:none;">
                </div>

                <button id="yy-save" style="margin-top:14px;width:100%;background:#ff2442;color:#fff;border:none;border-radius:10px;padding:11px;font-size:14px;font-weight:700;">Применить и сохранить</button>
            </div>
        `;

        document.body.appendChild(fab);
        document.body.appendChild(modal);

        function syncInputs() {
            document.getElementById("yy-adBlock").checked = !!cfg.adBlock;
            document.getElementById("yy-hideShorts").checked = !!cfg.hideShorts;
            document.getElementById("yy-hideHomeFeed").checked = !!cfg.hideHomeFeed;
            document.getElementById("yy-hideRelated").checked = !!cfg.hideRelated;
            document.getElementById("yy-hideComments").checked = !!cfg.hideComments;
            document.getElementById("yy-keywordFilter").value = cfg.keywordFilter || "";
            document.getElementById("yy-avatarShape").value = cfg.avatarShape || "circle";
            document.getElementById("yy-avatarBorderStyle").value = cfg.avatarBorderStyle || "neon";
            document.getElementById("yy-avatarBorderColor").value = cfg.avatarBorderColor || "#FF2442";
            document.getElementById("yy-avatarBorderWidth").value = cfg.avatarBorderWidth || 3;
            document.getElementById("yy-bwVal").textContent = cfg.avatarBorderWidth || 3;
            document.getElementById("yy-customIconEnabled").checked = !!cfg.customIconEnabled;
            document.getElementById("yy-iconColor").value = cfg.iconColor || "#FF2442";
        }

        document.getElementById("yy-avatarBorderWidth").addEventListener("input", (e) => {
            document.getElementById("yy-bwVal").textContent = e.target.value;
        });

        fab.addEventListener("click", () => {
            syncInputs();
            modal.style.display = "flex";
        });

        document.getElementById("yy-close").addEventListener("click", () => {
            modal.style.display = "none";
        });

        document.getElementById("yy-save").addEventListener("click", () => {
            cfg = {
                adBlock: document.getElementById("yy-adBlock").checked,
                hideShorts: document.getElementById("yy-hideShorts").checked,
                hideHomeFeed: document.getElementById("yy-hideHomeFeed").checked,
                hideRelated: document.getElementById("yy-hideRelated").checked,
                hideComments: document.getElementById("yy-hideComments").checked,
                keywordFilter: document.getElementById("yy-keywordFilter").value,
                avatarShape: document.getElementById("yy-avatarShape").value,
                avatarBorderStyle: document.getElementById("yy-avatarBorderStyle").value,
                avatarBorderColor: document.getElementById("yy-avatarBorderColor").value,
                avatarBorderWidth: parseInt(document.getElementById("yy-avatarBorderWidth").value, 10) || 3,
                customIconEnabled: document.getElementById("yy-customIconEnabled").checked,
                iconColor: document.getElementById("yy-iconColor").value
            };
            saveConfig(cfg);
            applyStyles();
            modal.style.display = "none";
        });
    }

    window.__youyubeAnonimApply = function() {
        applyStyles();
        createModUI();
        skipAdsTick();
    };

    window.__youyubeAnonimApply();

    const observer = new MutationObserver(() => {
        skipAdsTick();
        applyKeywordFilter();
        createModUI();
    });
    observer.observe(document.documentElement, { childList: true, subtree: true });
    setInterval(skipAdsTick, 600);
})();
