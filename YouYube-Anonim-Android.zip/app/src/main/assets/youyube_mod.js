(function() {
    const DEFAULT_CFG = {
        adBlock: true,
        hideShorts: false,
        hideHomeFeed: false,
        hideRelated: false,
        hideComments: false,
        keywordFilter: "",
        avatarShape: "circle",
        avatarBorderStyle: "neon",
        avatarBorderColor: "#FF2442",
        avatarBorderWidth: 3,
        iconColor: "#FF2442",
        customIconEnabled: true
    };

    function loadConfig() {
        try {
            if (window.YouYubeAnonimNative) {
                return Object.assign({}, DEFAULT_CFG, JSON.parse(window.YouYubeAnonimNative.getConfig()));
            }
        } catch (e) {}
        return Object.assign({}, DEFAULT_CFG);
    }

    let cfg = loadConfig();
    let lastShortsState = null;

    function ensureStyleEl() {
        let el = document.getElementById("yy-anonim-style");
        if (!el) {
            el = document.createElement("style");
            el.id = "yy-anonim-style";
            document.head.appendChild(el);
        }
        return el;
    }

    function getAvatarShapeCSS(shape) {
        switch (shape) {
            case "squircle":
                return "border-radius: 26% !important; clip-path: none !important; -webkit-clip-path: none !important;";
            case "square":
                return "border-radius: 6px !important; clip-path: none !important; -webkit-clip-path: none !important;";
            case "hexagon":
                return "border-radius: 0 !important; clip-path: polygon(50% 0%, 95% 25%, 95% 75%, 50% 100%, 5% 75%, 5% 25%) !important; -webkit-clip-path: polygon(50% 0%, 95% 25%, 95% 75%, 50% 100%, 5% 75%, 5% 25%) !important;";
            case "diamond":
                return "border-radius: 0 !important; clip-path: polygon(50% 0%, 100% 50%, 50% 100%, 0% 50%) !important; -webkit-clip-path: polygon(50% 0%, 100% 50%, 50% 100%, 0% 50%) !important;";
            case "circle":
            default:
                return "border-radius: 50% !important; clip-path: none !important; -webkit-clip-path: none !important;";
        }
    }

    function getAvatarBorderCSS(style, color, width) {
        if (style === "none") return "border: none !important; box-shadow: none !important;";
        if (style === "dashed") return `border: ${width}px dashed ${color} !important; box-shadow: none !important;`;
        if (style === "double") return `border: ${width}px double ${color} !important; box-shadow: none !important;`;
        if (style === "neon") return `border: ${width}px solid ${color} !important; box-shadow: 0 0 10px ${color}, 0 0 4px ${color} !important;`;
        if (style === "rainbow") return `border: ${width}px solid transparent !important; background: linear-gradient(135deg, #ff2442, #ffb800, #00e5ff, #9b51e0) border-box !important; box-shadow: 0 0 8px rgba(255,36,66,0.5) !important;`;
        return `border: ${width}px solid ${color} !important; box-shadow: none !important;`;
    }

    function applyStyles() {
        cfg = loadConfig();
        const el = ensureStyleEl();

        const avatarContainers = [
            "yt-avatar-shape",
            "yt-decorated-avatar-view-model",
            ".yt-spec-avatar-shape",
            ".yt-spec-avatar-shape__avatar-image-container",
            "ytm-profile-icon",
            "ytm-channel-thumbnail-with-link-renderer",
            "yt-img-shadow"
        ].join(", ");

        const avatarImgs = [
            "ytm-profile-icon img",
            "yt-avatar-shape img",
            ".yt-spec-avatar-shape img",
            ".yt-spec-avatar-shape__image",
            "ytm-channel-thumbnail-with-link-renderer img",
            "yt-img-shadow img",
            "#avatar img",
            ".channel-thumbnail img"
        ].join(", ");

        const iconSel = [
            "ytm-pivot-bar-item-renderer svg",
            "ytm-mobile-topbar-renderer svg",
            "ytm-slim-video-action-bar-renderer svg",
            "button.icon-button svg",
            ".yt-spec-button-shape-next__icon svg",
            "yt-icon svg"
        ].join(", ");

        let css = `
            ytm-open-app-button-renderer,
            .open-app-button,
            ytm-mealbar-promo-renderer,
            ytm-upsell-dialog-renderer,
            ytm-smart-app-banner-renderer,
            a[href^="intent://"],
            a[href*="play.google.com/store/apps"] {
                display: none !important;
            }

            ${avatarContainers} {
                ${getAvatarShapeCSS(cfg.avatarShape)}
                overflow: hidden !important;
            }

            ${avatarImgs} {
                ${getAvatarShapeCSS(cfg.avatarShape)}
                ${getAvatarBorderCSS(cfg.avatarBorderStyle, cfg.avatarBorderColor, cfg.avatarBorderWidth)}
                box-sizing: border-box !important;
                object-fit: cover !important;
            }
        `;

        if (cfg.customIconEnabled) {
            css += `
                ${iconSel} {
                    color: ${cfg.iconColor} !important;
                    fill: ${cfg.iconColor} !important;
                }
                ${iconSel} path {
                    fill: currentColor !important;
                }
            `;
        }

        if (cfg.adBlock) {
            css += `
                ytm-promoted-sparkles-web-renderer,
                ytm-promoted-sparkles-text-search-renderer,
                ytm-ad-slot-renderer,
                ytd-ad-slot-renderer,
                ytm-companion-slot-renderer,
                .ytp-ad-module,
                .ytp-ad-overlay-container,
                .ad-created-by-yt,
                [data-ad-slot-id] {
                    display: none !important;
                }
            `;
        }

        if (cfg.hideShorts) {
            css += `
                ytm-reel-shelf-renderer,
                ytm-shorts-lockup-view-model,
                ytm-pivot-bar-item-renderer[tab-identifier="FEshorts"],
                a[href^="/shorts"] {
                    display: none !important;
                }
            `;
        }

        if (cfg.hideHomeFeed) {
            css += `
                ytm-browse[data-browse-id="FEwhat_to_watch"] ytm-rich-grid-renderer,
                ytm-browse[data-browse-id="FEwhat_to_watch"] ytm-section-list-renderer {
                    display: none !important;
                }
            `;
        }

        if (cfg.hideRelated) {
            css += `
                ytm-item-section-renderer[section-identifier="related-items"],
                ytm-watch-next-secondary-results-renderer,
                ytm-single-column-watch-next-results-renderer ytm-section-list-renderer > lazy-list > ytm-item-section-renderer:nth-child(n+2) {
                    display: none !important;
                }
            `;
        }

        if (cfg.hideComments) {
            css += `
                ytm-comments-entry-point-header-renderer,
                ytm-comments-entry-point-teaser-renderer,
                ytm-comment-section-renderer,
                ytm-item-section-renderer[section-identifier="comments-entry-point"],
                ytm-engagement-panel-section-list-renderer[target-id="engagement-panel-comments-section"] {
                    display: none !important;
                }
            `;
        }

        el.textContent = css;
        applyDomFilters();
    }

    function applyDomFilters() {
        // 1. Hide Open App banners
        const phrases = ["открыть в приложении", "перейти в приложение", "открыть приложение", "open in app", "open app"];
        document.querySelectorAll("button, a, ytm-button-renderer, ytm-compact-link-renderer, ytm-menu-item").forEach(el => {
            const txt = (el.textContent || el.getAttribute("aria-label") || "").trim().toLowerCase();
            if (txt && phrases.some(p => txt.includes(p))) {
                const banner = el.closest("ytm-mealbar-promo-renderer, ytm-upsell-dialog-renderer, .open-app-button") || el;
                banner.style.setProperty("display", "none", "important");
            }
        });

        // 2. Hide comments robustly
        if (cfg.hideComments) {
            document.querySelectorAll("ytm-item-section-renderer, ytm-comments-entry-point-header-renderer, ytm-comments-entry-point-teaser-renderer, ytm-comment-section-renderer").forEach(sec => {
                const hasComments = sec.querySelector("ytm-comments-entry-point-teaser-renderer, ytm-comments-entry-point-header-renderer, ytm-comment-thread-renderer") ||
                    (sec.getAttribute("section-identifier") || "").includes("comment");
                if (hasComments || sec.tagName.toLowerCase().includes("comment")) {
                    sec.style.setProperty("display", "none", "important");
                }
            });
        } else {
            document.querySelectorAll("ytm-item-section-renderer").forEach(sec => {
                if ((sec.getAttribute("section-identifier") || "").includes("comment") || sec.querySelector("ytm-comments-entry-point-teaser-renderer")) {
                    sec.style.removeProperty("display");
                }
            });
        }

        // 3. Hide related videos robustly on watch page
        if (cfg.hideRelated) {
            document.querySelectorAll("ytm-single-column-watch-next-results-renderer ytm-item-section-renderer").forEach(sec => {
                if (sec.querySelector("ytm-video-with-context-renderer, ytm-compact-video-renderer, yt-lockup-view-model")) {
                    sec.style.setProperty("display", "none", "important");
                }
            });
        }

        // 4. Keyword filter
        const raw = (cfg.keywordFilter || "").trim();
        const keywords = raw ? raw.split(",").map(s => s.trim().toLowerCase()).filter(Boolean) : [];
        const cards = document.querySelectorAll(
            "ytm-video-with-context-renderer, ytm-rich-item-renderer, ytm-compact-video-renderer, ytm-video-card-renderer, yt-lockup-view-model, ytm-shorts-lockup-view-model"
        );
        cards.forEach(card => {
            if (!keywords.length) {
                card.style.removeProperty("display");
                return;
            }
            const text = (card.textContent || "").toLowerCase();
            if (keywords.some(kw => text.includes(kw))) {
                card.style.setProperty("display", "none", "important");
            } else {
                card.style.removeProperty("display");
            }
        });
    }

    function checkShortsState() {
        const isShorts = window.location.pathname.startsWith("/shorts") ||
            !!document.querySelector("ytm-shorts-page, ytm-reel-video-renderer");
        if (isShorts !== lastShortsState) {
            lastShortsState = isShorts;
            if (window.YouYubeAnonimNative && window.YouYubeAnonimNative.setShortsMode) {
                window.YouYubeAnonimNative.setShortsMode(isShorts);
            }
        }
    }

    function skipAdsTick() {
        if (!cfg.adBlock) return;
        const skipBtn = document.querySelector(".ytp-ad-skip-button, .ytp-ad-skip-button-modern, .ytp-skip-ad-button, button[class*='skip']");
        if (skipBtn) {
            skipBtn.click();
        }
        const player = document.querySelector(".html5-video-player");
        const video = document.querySelector("video");
        if (player && video && (player.classList.contains("ad-showing") || player.classList.contains("ad-interrupting"))) {
            video.muted = true;
            if (isFinite(video.duration) && video.duration > 0) {
                video.currentTime = video.duration;
            } else {
                video.playbackRate = 16.0;
            }
        }
    }

    window.__youyubeAnonimRefresh = function() {
        applyStyles();
        checkShortsState();
        skipAdsTick();
    };

    if (window.__youyubeAnonimLoaded) {
        window.__youyubeAnonimRefresh();
        return;
    }
    window.__youyubeAnonimLoaded = true;

    window.__youyubeAnonimRefresh();

    const observer = new MutationObserver(() => {
        skipAdsTick();
        applyDomFilters();
        checkShortsState();
    });
    observer.observe(document.documentElement, { childList: true, subtree: true });
    setInterval(() => {
        skipAdsTick();
        checkShortsState();
    }, 500);
})();
