(function() {
    if (window.__youyubeAnonimLoaded) {
        if (window.__youyubeAnonimApply) window.__youyubeAnonimApply();
        return;
    }
    window.__youyubeAnonimLoaded = true;

    const DEFAULT_CFG = {
        adBlock: true,
        hideShorts: false,
        hideHomeFeed: false,
        hideRelated: false,
        hideComments: false,
        keywordFilter: "",
        avatarShape: "circle",
        avatarBorderStyle: "neon",
        avatarBorderColor: "#FF2442",
        avatarBorderWidth: 3,
        iconColor: "#FF2442",
        customIconEnabled: true,
        showFloatingButton: true
    };

    function loadConfig() {
        try {
            if (window.YouYubeAnonimNative) {
                return Object.assign({}, DEFAULT_CFG, JSON.parse(window.YouYubeAnonimNative.getConfig()));
            }
            const local = localStorage.getItem("youyube_anonim_cfg");
            return local ? Object.assign({}, DEFAULT_CFG, JSON.parse(local)) : Object.assign({}, DEFAULT_CFG);
        } catch (e) {
            return Object.assign({}, DEFAULT_CFG);
        }
    }

    function saveConfig(cfg) {
        try {
            const str = JSON.stringify(cfg);
            localStorage.setItem("youyube_anonim_cfg", str);
            if (window.YouYubeAnonimNative) {
                window.YouYubeAnonimNative.saveConfig(str);
            }
        } catch (e) {}
    }

    let cfg = loadConfig();

    function ensureStyleEl() {
        let el = document.getElementById("yy-anonim-style");
        if (!el) {
            el = document.createElement("style");
            el.id = "yy-anonim-style";
            document.head.appendChild(el);
        }
        return el;
    }

    function getAvatarShapeCSS(shape) {
        switch (shape) {
            case "squircle":
                return "border-radius: 26% !important; clip-path: none !important;";
            case "square":
                return "border-radius: 6px !important; clip-path: none !important;";
            case "hexagon":
                return "border-radius: 0 !important; clip-path: polygon(50% 0%, 95% 25%, 95% 75%, 50% 100%, 5% 75%, 5% 25%) !important;";
            case "diamond":
                return "border-radius: 0 !important; clip-path: polygon(50% 0%, 100% 50%, 50% 100%, 0% 50%) !important;";
            case "circle":
            default:
                return "border-radius: 50% !important; clip-path: none !important;";
        }
    }

    function getAvatarBorderCSS(style, color, width) {
        if (style === "none") return "border: none !important; box-shadow: none !important;";
        if (style === "dashed") return `border: ${width}px dashed ${color} !important; box-shadow: none !important;`;
        if (style === "double") return `border: ${width}px double ${color} !important; box-shadow: none !important;`;
        if (style === "neon") return `border: ${width}px solid ${color} !important; box-shadow: 0 0 10px ${color}, 0 0 4px ${color} !important;`;
        if (style === "rainbow") return `border: ${width}px solid transparent !important; background: linear-gradient(135deg, #ff2442, #ffb800, #00e5ff, #9b51e0) border-box !important; box-shadow: 0 0 8px rgba(255,36,66,0.5) !important;`;
        return `border: ${width}px solid ${color} !important; box-shadow: none !important;`;
    }

    function applyStyles() {
        const el = ensureStyleEl();
        const avatarSel = [
            "ytm-profile-icon img",
            "yt-img-shadow img",
            ".yt-spec-avatar-shape__image",
            "ytm-channel-thumbnail-with-link-renderer img",
            "#avatar img",
            ".channel-thumbnail img"
        ].join(", ");

        const iconSel = [
            "ytm-pivot-bar-item-renderer svg",
            "ytm-mobile-topbar-renderer svg",
            "ytm-slim-video-action-bar-renderer svg",
            "button.icon-button svg",
            ".yt-spec-button-shape-next__icon svg",
            "yt-icon svg"
        ].join(", ");

        let css = `
            ${avatarSel} {
                ${getAvatarShapeCSS(cfg.avatarShape)}
                ${getAvatarBorderCSS(cfg.avatarBorderStyle, cfg.avatarBorderColor, cfg.avatarBorderWidth)}
                box-sizing: border-box !important;
                transition: all 0.2s ease !important;
            }
            .yt-spec-avatar-shape__avatar-image-container,
            yt-avatar-shape,
            .yt-spec-avatar-shape {
                ${getAvatarShapeCSS(cfg.avatarShape)}
                overflow: visible !important;
            }
        `;

        if (cfg.customIconEnabled) {
            css += `
                ${iconSel} {
                    color: ${cfg.iconColor} !important;
                    fill: ${cfg.iconColor} !important;
                }
                ${iconSel} path {
                    fill: currentColor !important;
                }
            `;
        }

        if (cfg.adBlock) {
            css += `
                ytm-promoted-sparkles-web-renderer,
                ytm-promoted-sparkles-text-search-renderer,
                ytm-ad-slot-renderer,
                ytd-ad-slot-renderer,
                ytm-companion-slot-renderer,
                .ytp-ad-module,
                .ytp-ad-overlay-container,
                .ad-created-by-yt,
                [data-ad-slot-id] {
                    display: none !important;
                }
            `;
        }

        if (cfg.hideShorts) {
            css += `
                ytm-reel-shelf-renderer,
                ytm-shorts-lockup-view-model,
                ytm-pivot-bar-item-renderer[tab-identifier="FEshorts"],
                a[href^="/shorts"] {
                    display: none !important;
                }
            `;
        }

        if (cfg.hideHomeFeed) {
            css += `
                ytm-browse[data-browse-id="FEwhat_to_watch"] ytm-rich-grid-renderer,
                ytm-browse[data-browse-id="FEwhat_to_watch"] ytm-section-list-renderer {
                    display: none !important;
                }
            `;
        }

        if (cfg.hideRelated) {
            css += `
                ytm-item-section-renderer[section-identifier="related-items"],
                ytm-single-column-watch-next-results-renderer ytm-section-list-renderer > lazy-list > ytm-item-section-renderer:nth-child(n+2) {
                    display: none !important;
                }
            `;
        }

        if (cfg.hideComments) {
            css += `
                ytm-comments-entry-point-header-renderer,
                ytm-comment-section-renderer {
                    display: none !important;
                }
            `;
        }

        el.textContent = css;
        applyKeywordFilter();

        const fab = document.getElementById("yy-anonim-fab");
        if (fab) {
            fab.style.display = cfg.showFloatingButton ? "block" : "none";
        }
    }

    function applyKeywordFilter() {
        const raw = (cfg.keywordFilter || "").trim();
        const keywords = raw ? raw.split(",").map(s => s.trim().toLowerCase()).filter(Boolean) : [];
        const cards = document.querySelectorAll("ytm-video-with-context-renderer, ytm-rich-item-renderer, ytm-compact-video-renderer");
        cards.forEach(card => {
            if (!keywords.length) {
                card.style.removeProperty("display");
                return;
            }
            const text = (card.innerText || "").toLowerCase();
            const matched = keywords.some(kw => text.includes(kw));
            if (matched) {
                card.style.display = "none";
            } else {
                card.style.removeProperty("display");
            }
        });
    }

    function skipAdsTick() {
        if (!cfg.adBlock) return;
        const skipBtn = document.querySelector(".ytp-ad-skip-button, .ytp-ad-skip-button-modern, .ytp-skip-ad-button, button[class*='skip']");
        if (skipBtn) {
            skipBtn.click();
        }
        const player = document.querySelector(".html5-video-player");
        const video = document.querySelector("video");
        if (player && video && (player.classList.contains("ad-showing") || player.classList.contains("ad-interrupting"))) {
            video.muted = true;
            if (isFinite(video.duration) && video.duration > 0) {
                video.currentTime = video.duration;
            } else {
                video.playbackRate = 16.0;
            }
        }
    }

    function openModModal() {
        const modal = document.getElementById("yy-anonim-modal");
        if (!modal) return;
        if (window.__yySyncInputs) window.__yySyncInputs();
        modal.style.display = "flex";
    }

    function injectIntoYouTubeSettings() {
        if (document.getElementById("yy-settings-menu-row")) return;

        // Look for native YouTube mobile settings list containers
        const settingsContainer =
            document.querySelector("ytm-settings ytm-setting-category-collection-renderer") ||
            document.querySelector("ytm-settings .settings-list") ||
            document.querySelector("ytm-settings") ||
            document.querySelector("ytm-browse[data-browse-id='FEsettings'] ytm-section-list-renderer");

        if (!settingsContainer) return;

        const row = document.createElement("div");
        row.id = "yy-settings-menu-row";
        row.setAttribute("role", "button");
        row.setAttribute("tabindex", "0");
        Object.assign(row.style, {
            display: "flex",
            alignItems: "center",
            justifyContent: "space-between",
            padding: "14px 16px",
            margin: "6px 12px 10px 12px",
            borderRadius: "12px",
            background: "linear-gradient(135deg, rgba(255,36,66,0.16), rgba(30,30,46,0.9))",
            border: "1px solid rgba(255,36,66,0.45)",
            cursor: "pointer",
            color: "#ffffff",
            fontFamily: "Roboto, Arial, sans-serif"
        });

        row.innerHTML = `
            <div style="display:flex;align-items:center;gap:14px;">
                <svg width="24" height="24" viewBox="0 0 24 24" fill="none" style="flex-shrink:0;">
                    <path d="M12 2L14.6 4.6L18.2 4.2L19.4 7.7L22.5 9.6L21.5 13.1L23 16.4L20.1 18.6L19.6 22.2L16 22.1L13.2 24L10.4 22.1L6.8 22.2L6.3 18.6L3.4 16.4L4.9 13.1L3.9 9.6L7 7.7L8.2 4.2L11.8 4.6L12 2Z" fill="${cfg.iconColor || '#FF2442'}" opacity="0.22"/>
                    <path d="M19.14 12.94c.04-.31.06-.63.06-.94s-.02-.63-.06-.94l2.03-1.58a.49.49 0 0 0 .12-.61l-1.92-3.32a.49.49 0 0 0-.59-.22l-2.39.96a7.03 7.03 0 0 0-1.62-.94l-.36-2.54a.484.484 0 0 0-.48-.41h-3.84c-.24 0-.43.17-.47.41l-.36 2.54c-.59.24-1.13.57-1.62.94l-2.39-.96a.49.49 0 0 0-.59.22L2.74 8.87a.48.48 0 0 0 .12.61l2.03 1.58c-.04.31-.06.63-.06.94s.02.63.06.94l-2.03 1.58a.49.49 0 0 0-.12.61l1.92 3.32c.12.22.37.29.59.22l2.39-.96c.5.38 1.03.7 1.62.94l.36 2.54c.05.24.24.41.48.41h3.84c.24 0 .44-.17.47-.41l.36-2.54c.59-.24 1.13-.56 1.62-.94l2.39.96c.22.08.47 0 .59-.22l1.92-3.32c.12-.22.07-.47-.12-.61l-2.01-1.58zM12 15.6A3.6 3.6 0 1 1 12 8.4a3.6 3.6 0 0 1 0 7.2z" fill="${cfg.iconColor || '#FF2442'}"/>
                </svg>
                <div>
                    <div style="font-size:15px;font-weight:600;line-height:1.25;">Настройки мода YouYube Anonim</div>
                    <div style="font-size:12px;color:#b8b8c8;margin-top:2px;">Реклама, рекомендации, рамка и форма аватарки, цвет значков</div>
                </div>
            </div>
            <span style="font-size:18px;color:#ff2442;font-weight:700;">›</span>
        `;

        row.addEventListener("click", (e) => {
            e.preventDefault();
            e.stopPropagation();
            openModModal();
        });

        settingsContainer.prepend(row);
    }

    function createModUI() {
        if (document.getElementById("yy-anonim-fab")) return;

        const fab = document.createElement("button");
        fab.id = "yy-anonim-fab";
        fab.textContent = "⚙ Anonim";
        Object.assign(fab.style, {
            display: cfg.showFloatingButton ? "block" : "none",
            position: "fixed",
            bottom: "72px",
            right: "14px",
            zIndex: "999999",
            background: "linear-gradient(135deg, #1a1a26, #2a1220)",
            color: "#ffffff",
            border: "1.5px solid #ff2442",
            borderRadius: "20px",
            padding: "8px 14px",
            fontSize: "12px",
            fontWeight: "700",
            boxShadow: "0 4px 14px rgba(255, 36, 66, 0.35)",
            cursor: "pointer"
        });

        const modal = document.createElement("div");
        modal.id = "yy-anonim-modal";
        Object.assign(modal.style, {
            display: "none",
            position: "fixed",
            inset: "0",
            zIndex: "1000000",
            background: "rgba(10, 10, 16, 0.85)",
            backdropFilter: "blur(6px)",
            alignItems: "center",
            justifyContent: "center",
            padding: "16px"
        });

        const swatches = ["#FF2442", "#00E5FF", "#00E676", "#FFB800", "#A855F7", "#FFFFFF"];
        function makeSwatchRow(targetId) {
            return `<div style="display:flex;gap:8px;margin:4px 0 8px;">` +
                swatches.map(c => `<button type="button" class="yy-swatch" data-target="${targetId}" data-color="${c}" style="width:24px;height:24px;border-radius:50%;border:2px solid #2e2e42;background:${c};cursor:pointer;"></button>`).join("") +
                `</div>`;
        }

        modal.innerHTML = `
            <div style="background:#161622;color:#f3f3f7;border:1px solid #2e2e42;border-radius:16px;width:100%;max-width:390px;max-height:86vh;overflow-y:auto;padding:18px;font-family:sans-serif;box-shadow:0 16px 40px rgba(0,0,0,0.65);">
                <div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:12px;">
                    <span style="font-size:17px;font-weight:700;color:#ff2442;">YouYube Anonim Mod</span>
                    <button id="yy-close" style="background:#262638;color:#fff;border:none;border-radius:8px;padding:6px 10px;font-size:13px;">✕</button>
                </div>

                <div style="font-size:12px;color:#9a9ab0;margin:10px 0 6px;font-weight:700;">РЕКЛАМА И РЕКОМЕНДАЦИИ</div>
                <label style="display:flex;justify-content:space-between;align-items:center;padding:6px 0;font-size:14px;">
                    <span>Авто-скрытие рекламы</span>
                    <input type="checkbox" id="yy-adBlock">
                </label>
                <label style="display:flex;justify-content:space-between;align-items:center;padding:6px 0;font-size:14px;">
                    <span>Скрыть Shorts</span>
                    <input type="checkbox" id="yy-hideShorts">
                </label>
                <label style="display:flex;justify-content:space-between;align-items:center;padding:6px 0;font-size:14px;">
                    <span>Скрыть ленту главной</span>
                    <input type="checkbox" id="yy-hideHomeFeed">
                </label>
                <label style="display:flex;justify-content:space-between;align-items:center;padding:6px 0;font-size:14px;">
                    <span>Скрыть похожие видео</span>
                    <input type="checkbox" id="yy-hideRelated">
                </label>
                <label style="display:flex;justify-content:space-between;align-items:center;padding:6px 0;font-size:14px;">
                    <span>Скрыть комментарии</span>
                    <input type="checkbox" id="yy-hideComments">
                </label>
                <div style="margin:6px 0 10px;">
                    <div style="font-size:13px;margin-bottom:4px;">Фильтр рекомендаций (слова через запятую):</div>
                    <input type="text" id="yy-keywordFilter" placeholder="реклама, обзор, кликбейт" style="width:100%;box-sizing:border-box;background:#0f0f18;color:#fff;border:1px solid #32324a;border-radius:8px;padding:8px;font-size:13px;">
                </div>

                <div style="font-size:12px;color:#9a9ab0;margin:12px 0 6px;font-weight:700;">АВАТАРКА</div>
                <div style="display:flex;justify-content:space-between;align-items:center;padding:6px 0;font-size:14px;">
                    <span>Форма аватарки</span>
                    <select id="yy-avatarShape" style="background:#0f0f18;color:#fff;border:1px solid #32324a;border-radius:8px;padding:5px 8px;">
                        <option value="circle">Круг</option>
                        <option value="squircle">Скругленный квадрат</option>
                        <option value="square">Квадрат</option>
                        <option value="hexagon">Шестиугольник</option>
                        <option value="diamond">Ромб</option>
                    </select>
                </div>
                <div style="display:flex;justify-content:space-between;align-items:center;padding:6px 0;font-size:14px;">
                    <span>Стиль рамки</span>
                    <select id="yy-avatarBorderStyle" style="background:#0f0f18;color:#fff;border:1px solid #32324a;border-radius:8px;padding:5px 8px;">
                        <option value="neon">Неоновое свечение</option>
                        <option value="solid">Сплошная</option>
                        <option value="dashed">Пунктир</option>
                        <option value="double">Двойная</option>
                        <option value="rainbow">Градиент</option>
                        <option value="none">Без рамки</option>
                    </select>
                </div>
                <div style="display:flex;justify-content:space-between;align-items:center;padding:6px 0;font-size:14px;">
                    <span>Цвет рамки</span>
                    <input type="color" id="yy-avatarBorderColor" style="width:44px;height:30px;border:none;background:none;">
                </div>
                ${makeSwatchRow("yy-avatarBorderColor")}
                <div style="display:flex;justify-content:space-between;align-items:center;padding:6px 0;font-size:14px;">
                    <span>Толщина рамки (<span id="yy-bwVal">3</span>px)</span>
                    <input type="range" id="yy-avatarBorderWidth" min="1" max="6" step="1">
                </div>

                <div style="font-size:12px;color:#9a9ab0;margin:12px 0 6px;font-weight:700;">ЗНАЧКИ И ИНТЕРФЕЙС</div>
                <label style="display:flex;justify-content:space-between;align-items:center;padding:6px 0;font-size:14px;">
                    <span>Свой цвет значков</span>
                    <input type="checkbox" id="yy-customIconEnabled">
                </label>
                <div style="display:flex;justify-content:space-between;align-items:center;padding:6px 0;font-size:14px;">
                    <span>Цвет значков</span>
                    <input type="color" id="yy-iconColor" style="width:44px;height:30px;border:none;background:none;">
                </div>
                ${makeSwatchRow("yy-iconColor")}
                <label style="display:flex;justify-content:space-between;align-items:center;padding:6px 0;font-size:14px;">
                    <span>Показывать кнопку ⚙ Anonim</span>
                    <input type="checkbox" id="yy-showFloatingButton">
                </label>

                <button id="yy-save" style="margin-top:14px;width:100%;background:#ff2442;color:#fff;border:none;border-radius:10px;padding:11px;font-size:14px;font-weight:700;">Применить и сохранить</button>
            </div>
        `;

        document.body.appendChild(fab);
        document.body.appendChild(modal);

        window.__yySyncInputs = function() {
            document.getElementById("yy-adBlock").checked = !!cfg.adBlock;
            document.getElementById("yy-hideShorts").checked = !!cfg.hideShorts;
            document.getElementById("yy-hideHomeFeed").checked = !!cfg.hideHomeFeed;
            document.getElementById("yy-hideRelated").checked = !!cfg.hideRelated;
            document.getElementById("yy-hideComments").checked = !!cfg.hideComments;
            document.getElementById("yy-keywordFilter").value = cfg.keywordFilter || "";
            document.getElementById("yy-avatarShape").value = cfg.avatarShape || "circle";
            document.getElementById("yy-avatarBorderStyle").value = cfg.avatarBorderStyle || "neon";
            document.getElementById("yy-avatarBorderColor").value = cfg.avatarBorderColor || "#FF2442";
            document.getElementById("yy-avatarBorderWidth").value = cfg.avatarBorderWidth || 3;
            document.getElementById("yy-bwVal").textContent = cfg.avatarBorderWidth || 3;
            document.getElementById("yy-customIconEnabled").checked = !!cfg.customIconEnabled;
            document.getElementById("yy-iconColor").value = cfg.iconColor || "#FF2442";
            document.getElementById("yy-showFloatingButton").checked = cfg.showFloatingButton !== false;
        };

        modal.querySelectorAll(".yy-swatch").forEach(btn => {
            btn.addEventListener("click", () => {
                const target = document.getElementById(btn.getAttribute("data-target"));
                if (target) target.value = btn.getAttribute("data-color");
            });
        });

        document.getElementById("yy-avatarBorderWidth").addEventListener("input", (e) => {
            document.getElementById("yy-bwVal").textContent = e.target.value;
        });

        fab.addEventListener("click", openModModal);

        document.getElementById("yy-close").addEventListener("click", () => {
            modal.style.display = "none";
        });

        document.getElementById("yy-save").addEventListener("click", () => {
            cfg = {
                adBlock: document.getElementById("yy-adBlock").checked,
                hideShorts: document.getElementById("yy-hideShorts").checked,
                hideHomeFeed: document.getElementById("yy-hideHomeFeed").checked,
                hideRelated: document.getElementById("yy-hideRelated").checked,
                hideComments: document.getElementById("yy-hideComments").checked,
                keywordFilter: document.getElementById("yy-keywordFilter").value,
                avatarShape: document.getElementById("yy-avatarShape").value,
                avatarBorderStyle: document.getElementById("yy-avatarBorderStyle").value,
                avatarBorderColor: document.getElementById("yy-avatarBorderColor").value,
                avatarBorderWidth: parseInt(document.getElementById("yy-avatarBorderWidth").value, 10) || 3,
                customIconEnabled: document.getElementById("yy-customIconEnabled").checked,
                iconColor: document.getElementById("yy-iconColor").value,
                showFloatingButton: document.getElementById("yy-showFloatingButton").checked
            };
            saveConfig(cfg);
            applyStyles();
            modal.style.display = "none";
        });
    }

    window.__youyubeAnonimApply = function() {
        applyStyles();
        createModUI();
        injectIntoYouTubeSettings();
        skipAdsTick();
    };

    window.__youyubeAnonimApply();

    const observer = new MutationObserver(() => {
        skipAdsTick();
        applyKeywordFilter();
        createModUI();
        injectIntoYouTubeSettings();
    });
    observer.observe(document.documentElement, { childList: true, subtree: true });
    setInterval(skipAdsTick, 600);
})();
